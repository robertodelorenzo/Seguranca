import { Component } from '@angular/core';

import { NavController } from 'ionic-angular';

import {Md5} from 'ts-md5/dist/md5';

import { SecureStorage } from 'ionic-native';

import { PushRegisterService } from '../../app/push-service';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  username:string;
  password:string;
  constructor(public navCtrl: NavController, push:PushRegisterService) {
  push.register();
  }

	onLogin() { 
	    alert(this.username);
	    alert(this.password);
	}

	validaLogin(){ 
	    var pwd = localStorage.getItem(this.username);
	    if(!pwd){
//	    	var t = Md5.hashStr('blah blah blah').toString();
	    	var t = Md5.hashStr('saiFora6nao@minhaSenha').toString();
	    	localStorage.setItem(this.username, t);
	    }
	    else{
	       if(pwd == this.password)
	          alert('Seja bem-vindo!');
	       else  
	          alert('Sua senha é invalida');
	    }
	}  

   
public saveUser() {

	let secureStorage: SecureStorage = new SecureStorage();
	secureStorage.create('my_store_name')
	 .then(
	   () => console.log('Storage is ready!'),
	   error => console.log(error)
	);

	secureStorage.get('myitem')
	 .then(
	   data => console.log(data),
	   error => console.log(error)
	);

	secureStorage.set('myitem', 'myvalue')
	 .then(
	   data => console.log(data),
	   error => console.log(error)
	);

	secureStorage.remove('myitem')
	.then(
	   data => console.log(data),
	   error => console.log(error)
	);
}   

}


